package edu;

// Pure abstraction
public interface ProgressTrackable {
	
	 void trackProgress();

}
